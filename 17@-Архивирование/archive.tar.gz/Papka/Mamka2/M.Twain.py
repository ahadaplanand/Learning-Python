var = '''There is a time in every boy's life when he wants to go
and ,digfor treasure. ,And that time came for Tom.
So, one hot summer's day, he went to find Huck .
Huck liked the idea.oftreasure. 'Where are we going
to dig?' he asked.'''

print(var)
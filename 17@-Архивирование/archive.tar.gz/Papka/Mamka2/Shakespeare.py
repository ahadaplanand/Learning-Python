var = '''Ham. Thou pray'st not well.
    I prithee take thy fingers from my throat;
    For, though I am not splenitive and rash,
    Yet have I in me something dangerous,
    Which let thy wisdom fear. Hold off thy hand!
  King. Pluck thein asunder.
  Queen. Hamlet, Hamlet!
  All. Gentlemen!
  Hor. Good my lord, be quiet.
             [The Attendants part them, and they come out of the grave.]'''

print(var)
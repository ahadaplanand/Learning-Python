import time

print('One')
time.sleep(1)
print('Two')